﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Gcm.Client;
using Android.Graphics;

namespace AXMobile.Droid
{

    //doc: https://github.com/KSemenenko/AzurePushNotificationsForXamarinForms

    [BroadcastReceiver(Permission = Constants.PermissionGcmIntents)]
    [IntentFilter(new[] { Intent.ActionBootCompleted })] // Allow GCM on boot and when app is closed   
    [IntentFilter(new[] { Constants.IntentFromGcmMessage }, Categories = new[] { "com.highviewsoft.ax.droid" })]
    [IntentFilter(new[] { Constants.IntentFromGcmRegistrationCallback }, Categories = new[] { "com.highviewsoft.ax.droid" })]
    [IntentFilter(new[] { Constants.IntentFromGcmLibraryRetry }, Categories = new[] { "com.highviewsoft.ax.droid" })]
    public class PushNotificationsBroadcastReceiver: GcmBroadcastReceiverBase<AppGcmService>
    {

    }

    [Service] //Must use the service tag
    public class AppGcmService : GcmServiceBase
    {
        protected override void OnMessage(Context context, Intent intent)
        {
            if (intent != null || intent.Extras != null)
            {
                string msg = intent.Extras.GetString("message");
                SendNotification(context, msg);
                Console.WriteLine("Received Notification: " + msg);
            }
        }

        void SendNotification(Context context, string msg)
        {
            var notificationBuilder = new Notification.Builder(this);
            Bitmap bm = BitmapFactory.DecodeResource(context.Resources, Resource.Drawable.Icon);
            notificationBuilder.SetSmallIcon(Resource.Drawable.Icon);
            notificationBuilder.SetPriority(1);
            notificationBuilder.SetLargeIcon(bm);
            notificationBuilder.SetContentTitle("AX");
            notificationBuilder.SetContentText(msg);
            notificationBuilder.SetAutoCancel(true);
            notificationBuilder.SetDefaults(NotificationDefaults.Sound);

            var notificationManager = (NotificationManager)GetSystemService(Context.NotificationService);
            notificationManager.Notify(0, notificationBuilder.Build());
        }
    }

}
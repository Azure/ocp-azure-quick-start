﻿using MvvmCross.Forms.Core;
using Xamarin.Forms.Xaml;

namespace AXMobile.Core.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MeetingListPage : MvxContentPage
    {
        public MeetingListPage()
        {
            InitializeComponent();
        }
    }
}
﻿using MvvmCross.Forms.Core;
using Xamarin.Forms.Xaml;

namespace AXMobile.Core.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MeetingDetailPage : MvxContentPage
    {
        public MeetingDetailPage()
        {
            InitializeComponent();
        }
    }
}
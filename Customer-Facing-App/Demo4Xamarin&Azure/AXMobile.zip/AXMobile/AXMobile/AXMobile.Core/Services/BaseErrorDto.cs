﻿
namespace AXMobile.Core.Services
{
    public class BaseErrorDto
    {
        public bool IsSucceed { get; set; }

        public string ErrorKey { get; set; }

        public string ErrorMessage { get; set; }
    }
}

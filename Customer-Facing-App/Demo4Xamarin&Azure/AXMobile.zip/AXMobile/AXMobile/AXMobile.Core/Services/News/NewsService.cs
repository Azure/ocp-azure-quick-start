﻿using AXMobile.Core.Helpers;
using AXMobile.Core.Services.Meetings;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using AXMobile.Core;

namespace AXMobile.Core.Services.News
{
    class NewsService : INewsService
    {
        public async Task<Tuple<NewsListItemDto, BaseErrorDto>> GetNewsListAsync()
        {
            string url = $"{AXMobile.Core.AppConstants.Base_API_Url}news/list?pageIndex=0";
            try
            {
                HttpResponseMessage response = await HttpClientHelper.GetAsync(url);

                switch (response.StatusCode)
                {
                    //200
                    case System.Net.HttpStatusCode.OK:
                        var Issuccess = await response.Content.ReadAsStringAsync();
                        var items = JsonConvert.DeserializeObject<NewsListItemDto>(Issuccess);
                        return new Tuple<NewsListItemDto, BaseErrorDto>(items, new BaseErrorDto { IsSucceed = true });

                    //500
                    case System.Net.HttpStatusCode.InternalServerError:
                        var isSuccess = await response.Content.ReadAsStringAsync();
                        var content = JsonConvert.DeserializeObject<CommonErrorDto>(isSuccess);
                        return new Tuple<NewsListItemDto, BaseErrorDto>(null, new BaseErrorDto { IsSucceed = false, ErrorMessage = content.Error.Message });

                    //404
                    case System.Net.HttpStatusCode.NotFound:
                        return new Tuple<NewsListItemDto, BaseErrorDto>(null, new BaseErrorDto { IsSucceed = false, ErrorKey = "NotFund" });
                    default:
                        return new Tuple<NewsListItemDto, BaseErrorDto>(null, new BaseErrorDto { IsSucceed = false, ErrorKey = "UnexpectedError" });
                }
            }
            catch
            {
                return new Tuple<NewsListItemDto, BaseErrorDto>(null, new BaseErrorDto { IsSucceed = false, ErrorKey = "ServerConnectError" });
            }
        }

        public async Task<Tuple<NewsDetailDto, BaseErrorDto>> GetNewsDetailAsync(int id)
        {
            string url = $"{AXMobile.Core.AppConstants.Base_API_Url}news/get/{id}";

            try
            {
                HttpResponseMessage response = await HttpClientHelper.GetAsync(url);

                switch (response.StatusCode)
                {
                    //200
                    case System.Net.HttpStatusCode.OK:
                        var issuccess = await response.Content.ReadAsStringAsync();
                        var items = JsonConvert.DeserializeObject<NewsDetailDto>(issuccess);
                        return new Tuple<NewsDetailDto, BaseErrorDto>(items, new BaseErrorDto { IsSucceed = true });
                    //500
                    case System.Net.HttpStatusCode.InternalServerError:
                        var Issuccess = await response.Content.ReadAsStringAsync();
                        var Content = JsonConvert.DeserializeObject<CommonErrorDto>(Issuccess);
                        return new Tuple<NewsDetailDto, BaseErrorDto>(null, new BaseErrorDto { IsSucceed = false, ErrorMessage = Content.Error.Message });
                    //404
                    case System.Net.HttpStatusCode.NotFound:
                        return new Tuple<NewsDetailDto, BaseErrorDto>(null, new BaseErrorDto { IsSucceed = false, ErrorKey = "NotFund" });
                    default:
                        return new Tuple<NewsDetailDto, BaseErrorDto>(null, new BaseErrorDto { IsSucceed = false, ErrorKey = "UnexpectedError" });
                }
            }
            catch
            {
                return new Tuple<NewsDetailDto, BaseErrorDto>(null, new BaseErrorDto { IsSucceed = false, ErrorKey = "ServerConnectError" });
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AXMobile.Core.Services.News
{
    public interface INewsService
    {
        Task<Tuple<NewsListItemDto, BaseErrorDto>> GetNewsListAsync();
        Task<Tuple<NewsDetailDto, BaseErrorDto>> GetNewsDetailAsync(int id);
    }
}

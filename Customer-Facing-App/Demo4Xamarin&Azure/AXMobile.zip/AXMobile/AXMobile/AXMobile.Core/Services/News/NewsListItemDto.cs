﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AXMobile.Core.Services.News
{
    public class NewsListItemDto
    {
        public int Totacount { get; set; }

        public List<Items> Items { get; set; }
    }
    public class Items
    {
        public string Title { get; set; }

        public DateTime CreationTime { get; set; }

        public string PictureUrl { get; set; }

        public int Id { get; set; }
    }
}

﻿using AXMobile.Core.Helpers;
using AXMobile.Core.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace AXMobile.Core.Services.Meetings
{
    public class MeetingService : IMeetingService
    {
        public async Task<Tuple<MeetingsDto, BaseErrorDto>> GetMeetingsAsync(int id)
        {
            string url = $"{AXMobile.Core.AppConstants.Base_API_Url}/Meeting/get/{id}";
            
            try
            {
                HttpResponseMessage response = await HttpClientHelper.GetAsync(url);
                //登录成功
                switch (response.StatusCode)
                {
                    //200
                    case System.Net.HttpStatusCode.OK:
                        var content_success = await response.Content.ReadAsStringAsync();
                        var items = JsonConvert.DeserializeObject<MeetingsDto>(content_success);
                        return new Tuple<MeetingsDto, BaseErrorDto>(items,new BaseErrorDto { IsSucceed = true});
                    //500
                    case System.Net.HttpStatusCode.InternalServerError:
                        var content = await response.Content.ReadAsStringAsync();
                        var commonError = JsonConvert.DeserializeObject<CommonErrorDto>(content);
                        return new Tuple<MeetingsDto, BaseErrorDto>(null, new BaseErrorDto { IsSucceed = false,ErrorMessage = commonError.Error.Message });
                    //404
                    case System.Net.HttpStatusCode.NotFound:
                        return new Tuple<MeetingsDto, BaseErrorDto>(null, new BaseErrorDto { IsSucceed = false, ErrorKey = "NotFund" });
                    default:
                        return new Tuple<MeetingsDto, BaseErrorDto>(null, new BaseErrorDto { IsSucceed = false, ErrorKey = "UnexpectedError" });
                }
            }
            catch (Exception e)
            {
                var s = e.Message;
                return new Tuple<MeetingsDto, BaseErrorDto>(null, new BaseErrorDto { IsSucceed = false, ErrorKey = "ServerConnectError" });
            }

        }

        public async Task<Tuple<MeetingsListItemDto, BaseErrorDto>> GetMeetingsListAsync ( )
        {
            string url = $"{AXMobile.Core.AppConstants.Base_API_Url}/meeting/list?pageIndex=0";
            //string url = "https://projectax.azurewebsites.net/api/meeting/list?pageIndex=0";
            try
            {
                HttpResponseMessage response = await HttpClientHelper.GetAsync(url);
                //登录成功
                switch (response.StatusCode)
                {
                    //200
                    case System.Net.HttpStatusCode.OK:
                        var content_success = await response.Content.ReadAsStringAsync();
                        var items = JsonConvert.DeserializeObject<MeetingsListItemDto>(content_success);
                        return new Tuple<MeetingsListItemDto, BaseErrorDto>(items, new BaseErrorDto { IsSucceed = true });
                    //500
                    case System.Net.HttpStatusCode.InternalServerError:
                        var content = await response.Content.ReadAsStringAsync();
                        var commonError = JsonConvert.DeserializeObject<CommonErrorDto>(content);
                        return new Tuple<MeetingsListItemDto, BaseErrorDto>(null, new BaseErrorDto { IsSucceed = false, ErrorMessage = commonError.Error.Message });
                    default:
                        return new Tuple<MeetingsListItemDto, BaseErrorDto>(null, new BaseErrorDto { IsSucceed = false, ErrorKey = "UnexpectedError" });
                }
            }
            catch (Exception e)
            {
                var s = e.Message;
                return new Tuple<MeetingsListItemDto, BaseErrorDto>(null, new BaseErrorDto { IsSucceed = false, ErrorKey = "ServerConnectError" });
            }
            //await Task.Delay(1000);

            //return new List<MeetingsListItemDto>
            //{
            //   new MeetingsListItemDto{meetingId = "1234" ,title = "新产品发布会", datePublished = DateTime.Today, timeAndAddress="10:00 —— 12:00|振华企业广场A 1002"},
            //   new MeetingsListItemDto{meetingId = "1235" , title = "集团会议", datePublished = DateTime.Today, timeAndAddress="13:00 —— 14:00|振华企业广场A 1102"},
            //   new MeetingsListItemDto{meetingId = "1236" , title = "新年运动大会", datePublished = DateTime.Today, timeAndAddress="15:00 —— 18:00|振华企业广场A 1302"},
            //   new MeetingsListItemDto{meetingId = "1237" , title = "新产品发布会", datePublished = new DateTime(2017,8,2), timeAndAddress="10:00 —— 12:00|振华企业广场A 1002"},
            //   new MeetingsListItemDto{meetingId = "1238" , title = "集团会议", datePublished = new DateTime(2017,8,2), timeAndAddress="13:00 —— 14:00|振华企业广场A 1102"},
            //   new MeetingsListItemDto{meetingId = "1239" , title = "新年运动大会", datePublished = new DateTime(2017,8,2), timeAndAddress="15:00 —— 18:00|振华企业广场A 1302"},
            //};
        }
    }
}
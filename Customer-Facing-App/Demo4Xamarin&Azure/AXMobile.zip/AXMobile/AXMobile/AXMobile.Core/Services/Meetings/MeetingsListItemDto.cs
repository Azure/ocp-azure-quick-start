﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AXMobile.Core.Services.Meetings
{
    public class MeetingsListItemDto
    {
        public int TotalCount { get; set; }

        public List<Items> Items { get; set; }
    }

    public class Items
    {
        public string Subject { get; set; }
        public string Location { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public int Id { get; set; }
    }
}

﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AXMobile.Core.Services.Meetings
{
    public class MeetingsDto
    {
        public int Id { get; set; }
        public string Subject { get; set; }
        public string Location { get; set; }
        public string MoreInfo { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public string PictureUrl { get; set; }
    }
}
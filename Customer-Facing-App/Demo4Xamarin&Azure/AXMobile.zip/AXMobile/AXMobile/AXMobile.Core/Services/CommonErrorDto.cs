﻿
using System.Collections.Generic;

namespace AXMobile.Core.Services
{
    public class CommonErrorDto
    {
        public string Result { get; set; }
        public string TargetUrl { get; set; }
        public bool Success { get; set; }
        public Error Error { get; set; }
        public bool UnAuthorizedRequest { get; set;}
        public bool __abp { get; set; }
    }

    public class Error
    {
        public int code { get; set; }

        public string Message { get; set; }

        public string Details { get; set; }

        public List<ValidationErrors> ValidationErrors { get; set; }
    }

    public class ValidationErrors
    {
        public string Message { get; set; }

        public List<string> Members { get; set; }
    }
}

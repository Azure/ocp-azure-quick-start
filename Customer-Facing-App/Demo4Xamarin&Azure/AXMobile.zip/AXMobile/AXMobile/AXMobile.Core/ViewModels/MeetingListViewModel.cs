﻿using MvvmCross.Core.ViewModels;
using System;
using System.Collections.Generic;
using Xamarin.Forms;
using System.Threading.Tasks;
using MvvmCross.Platform;
using System.Globalization;
using Acr.UserDialogs;
using MvvmCross.Core.Navigation;
using AXMobile.Core.Services.Meetings;
using AXMobile.Core.Model;
using AXMobile.Core.Helpers;

namespace AXMobile.Core.ViewModels
{
    public class MeetingListViewModel : MvxViewModel
    {
        public List<MeetingListItem> All { get; private set; }


        private readonly IMeetingService _meetingService;
        private readonly IMvxNavigationService _navigationService;
        private readonly Services.IAppSettings _settings;
        private readonly IUserDialogs _userDialogs;

        public MeetingListViewModel()
        {
            _meetingService = Mvx.Resolve<IMeetingService>();
            _navigationService = Mvx.Resolve<IMvxNavigationService>();
            _settings = Mvx.Resolve<Services.IAppSettings>();
            _userDialogs = Mvx.Resolve<IUserDialogs>();
        }

        public async Task SourceToModel()
        {
            this.IsRefreshing = true;
            var result = await _meetingService.GetMeetingsListAsync();
            UserDialogs.Instance.HideLoading();
            if (result.Item2.IsSucceed)
            {
                List<MeetingListItem> meetingListSource = new List<MeetingListItem>();
                DateTime lastMeetingDate = DateTime.Today.Date;
                foreach (Items meetingItem in result.Item1.Items)
                {
                    //meeting.MeetingDateTime = meetingItem.datePublished.Equals(DateTime.Today) ? "今天" : meetingItem.datePublished.ToString();
                    if (meetingItem.StartTime.Date.Equals(lastMeetingDate))
                    {
                        if (lastMeetingDate.Equals(DateTime.Today.Date))
                        {
                            MeetingListItem meeting = new MeetingListItem();
                            meeting.MeetingDateTime = "今天";
                            meeting.MeetingDateTimeSize = 16;
                            meeting.MeetingDateMonthVisible = false;
                            meeting.GroupHeaderBackgroundColor = "#42a5f5";
                            meeting.GroupHeaderTextColor = "#FFFFFF";
                            //add image source
                            meeting.GroupHeaderImageSource = "blue.png";
                            meeting.MeetingId = meetingItem.Id;
                            meeting.TimeText = $"{meetingItem.StartTime.ToString("HH:mm")}——{meetingItem.EndTime.ToString("HH:mm")}";
                            meeting.NameText = meetingItem.Subject;
                            meeting.AddressText = meetingItem.Location;
                            meetingListSource.Add(meeting);
                        }
                    }
                    else
                    {
                        lastMeetingDate = meetingItem.StartTime.Date;

                        MeetingListItem meeting = new MeetingListItem();
                        meeting.MeetingDateTime = $"{meetingItem.StartTime.ToString("dd")}";
                        meeting.MeetingDateTimeSize = 17;
                        meeting.MeetingDateMonth = $"{meetingItem.StartTime.ToString("MMM")}";
                        meeting.MeetingDateMonthVisible = true;
                        meeting.GroupHeaderBackgroundColor = "#7e57c2";
                        meeting.GroupHeaderTextColor = "#000000";
                        //add image source
                        meeting.GroupHeaderImageSource = "purple.png";
                        meeting.MeetingId = meetingItem.Id;
                        meeting.TimeText = $"{meetingItem.StartTime.ToString("HH:mm")}——{meetingItem.EndTime.ToString("HH:mm")}";

                        meeting.NameText = meetingItem.Subject;
                        meeting.AddressText = meetingItem.Location;

                        meetingListSource.Add(meeting);
                    }
                }
                this.All = meetingListSource;
                this.IsRefreshing = false;
            }
            else
            {
                if (!string.IsNullOrEmpty(result.Item2.ErrorKey))
                    _userDialogs.Alert(result.Item2.ErrorKey);
                else
                    _userDialogs.Alert(result.Item2.ErrorMessage);
            }
            
        }

        public MeetingListItem SelectedMeetingListItem { get; set; }

        public bool IsRefreshing { get; set; }
        
        public IMvxAsyncCommand RefreshCommand => new MvxAsyncCommand(async()=>
        {
            await SourceToModel();
        });
        public IMvxCommand ToDetailCommand => new MvxCommand(() =>
        {
            if (this.SelectedMeetingListItem == null)
                return;
            _navigationService.Navigate<MettingDetailViewModel, MeetingListItem>(this.SelectedMeetingListItem);
            if (this.SelectedMeetingListItem != null)
                SelectedMeetingListItem = null;
        });

    }
}

﻿using Acr.UserDialogs;
using AXMobile.Core.Model;
using AXMobile.Core.Services.News;
using MvvmCross.Core.ViewModels;
using MvvmCross.Platform;
using Plugin.Connectivity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AXMobile.Core.ViewModels
{
    public class NewsDetailViewModel : MvxViewModel<NewsListItem>
    {
        private readonly INewsService _newsService;
        private readonly Services.IAppSettings _settings;
        private readonly IUserDialogs _userDialogs;
        public NewsDetailViewModel()
        {
            _newsService = Mvx.Resolve<INewsService>();
            _userDialogs = Mvx.Resolve<IUserDialogs>();
            _settings = Mvx.Resolve<Services.IAppSettings>();
        }

        public string Title_ViewModel { get; set; }
        public string Content_ViewModel { get; set; }
        public string PictureUrl_ViewModel { get; set; }
        public int ID_ViewModel { get; set; }

        public override async Task Initialize(NewsListItem parameter)
        {
            if (!CrossConnectivity.Current.IsConnected)
            {
                _userDialogs.Alert("网络异常");
                return;
            }
            UserDialogs.Instance.ShowLoading("加载中");
            var result = await _newsService.GetNewsDetailAsync(parameter.Id);
            UserDialogs.Instance.HideLoading();

            if (result.Item2.IsSucceed)
            {
                this.Title_ViewModel = result.Item1.Title;
                this.Content_ViewModel = result.Item1.Content;
                this.PictureUrl_ViewModel = result.Item1.PictureUrl;
                this.ID_ViewModel = result.Item1.ID;
            }
            else
            {
                if (!string.IsNullOrEmpty(result.Item2.ErrorKey))
                    _userDialogs.Alert(result.Item2.ErrorKey);
                else
                    _userDialogs.Alert(result.Item2.ErrorMessage);
            }
        }
    }
}


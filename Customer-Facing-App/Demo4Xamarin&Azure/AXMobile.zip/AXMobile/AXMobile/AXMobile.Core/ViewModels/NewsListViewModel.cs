﻿using Acr.UserDialogs;
using AXMobile.Core.Model;
using AXMobile.Core.Services;
using AXMobile.Core.Services.News;
using MvvmCross.Core.Navigation;
using MvvmCross.Core.ViewModels;
using MvvmCross.Platform;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace AXMobile.Core.ViewModels
{
    public class NewsListViewModel:MvxViewModel
    {
        public List<NewsListItem> All { get; set; }

        private readonly INewsService _newsService;
        private readonly IMvxNavigationService _mvxNavigationService;
        private readonly IAppSettings _settings;
        private readonly IUserDialogs _userDialogs;

        public NewsListItem SelectNewsListItem { get; set; }
        public bool IsRefresh { get; set; }
        public NewsListViewModel()
        {
            _newsService = Mvx.Resolve<INewsService>();
            _mvxNavigationService = Mvx.Resolve<IMvxNavigationService>();
            _settings = Mvx.Resolve<IAppSettings>();
            _userDialogs = Mvx.Resolve<IUserDialogs>();
    
            RefreshCommand.ExecuteAsync(SourceToModel());
        }
        public IMvxAsyncCommand RefreshCommand => new MvxAsyncCommand(async () =>
        {
            await SourceToModel();
    
        });
        private async Task SourceToModel()
        {
            this.IsRefresh = true;
            var result = await _newsService.GetNewsListAsync();
            UserDialogs.Instance.HideLoading();
            if(result.Item2.IsSucceed)
            {
                All = new List<NewsListItem>();
                NewsListItem newsListItem = new NewsListItem();
                DateTime lastMeetingDate = DateTime.Today.Date;
                foreach(Items newsItem in result.Item1.Items)
                {
                    NewsListItem _newsListItem = new NewsListItem();
                    _newsListItem.Id = newsItem.Id;
                    _newsListItem.CreationTime = newsItem.CreationTime;
                    _newsListItem.PictureUrl = newsItem.PictureUrl;
                    _newsListItem.Title = newsItem.Title;
                    All.Add(_newsListItem);
                }
                this.IsRefresh = false;
            }
            else
            {
                if (!string.IsNullOrEmpty(result.Item2.ErrorKey))
                    _userDialogs.Alert(result.Item2.ErrorKey);
                else
                    _userDialogs.Alert(result.Item2.ErrorMessage);
            }
        }

        public IMvxAsyncCommand GoToNewsDetail => new MvxAsyncCommand(async() =>
         {
             if ( this.SelectNewsListItem== null)
                 return;
             await _mvxNavigationService.Navigate<NewsDetailViewModel,NewsListItem>(this.SelectNewsListItem);
             SelectNewsListItem = null;
             if (this.SelectNewsListItem != null)
                 SelectNewsListItem = null;
         });
    }
}

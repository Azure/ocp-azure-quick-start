﻿using AXMobile.Core.Helpers;
using MvvmCross.Core.Navigation;
using MvvmCross.Core.ViewModels;
using Plugin.AzurePushNotifications;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace AXMobile.Core.ViewModels
{
    class LoginViewModel:MvxViewModel
    {
        private readonly IMvxNavigationService _navigationService;
        public LoginViewModel(IMvxNavigationService navigationService)
        {
            _navigationService = navigationService;
        }

        public IMvxAsyncCommand GoToMainPage => new MvxAsyncCommand(async () =>
        {
            PushNotificationCredentials.GoogleApiSenderId = AppConstants.Google_Api_Sender_Id;
            PushNotificationCredentials.AzureNotificationHubName = AppConstants.Azure_Notification_Hub_Name;
            PushNotificationCredentials.AzureListenConnectionString = AppConstants.Azure_Notification_Hub_ListenConnectionString;
            CrossAzurePushNotifications.Current.RegisterForAzurePushNotification();

            await _navigationService.Navigate<MainViewModel>();
            ClearStackHelper.ClearBackStack();
        });

        public IMvxCommand OpenGithubUrlCommand =>
            new MvxCommand(() =>
            {
                Device.OpenUri(new Uri("http://www.highviewsoft.com"));
            });
    }
}

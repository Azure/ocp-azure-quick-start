﻿using Acr.UserDialogs;
using AXMobile.Core.Model;
using AXMobile.Core.Services.Meetings;
using MvvmCross.Core.Navigation;
using MvvmCross.Core.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Plugin.Connectivity;
using Xamarin.Forms;

namespace AXMobile.Core.ViewModels
{
    public class MettingDetailViewModel : MvxViewModel<MeetingListItem>
    {
        private readonly IMvxNavigationService _navigationService;
        private readonly Services.IAppSettings _settings;
        private readonly Services.Meetings.IMeetingService _meetingService;
        private readonly IUserDialogs _userDialogs;
        public MettingDetailViewModel(IMvxNavigationService navigationService, Services.IAppSettings settings, IMeetingService meetingService, IUserDialogs userDialogs)
        {
            _navigationService = navigationService;
            _settings = settings;
            _meetingService = meetingService;
            _userDialogs = userDialogs;
            
        }
        public string MeetingName { get; private set; }
        public string MeetingAdress { get; private set; }
        public string MeetingDateDay { get; private set; }
        public string MeetingDateMonth { get; private set; }
        public string MeetingTime { get; private set; }
        public string MeetingContent { get; private set; }
        public string PictureUrl { get; private set; }
        public string DateNow { get; private set; }
        public string MeetingYear { get; private set; }
        public override async Task Initialize(MeetingListItem parameter)
        {
            //网络判断
            if (!CrossConnectivity.Current.IsConnected)
            {
                _userDialogs.Alert("网络异常");
                return;
               
            }
            UserDialogs.Instance.ShowLoading("加载中");
            var result = await _meetingService.GetMeetingsAsync(parameter.MeetingId);
            UserDialogs.Instance.HideLoading();
            if (result.Item2.IsSucceed)
            {
                this.MeetingDateDay = $"{result.Item1.StartTime.ToString("dd")}";
                this.MeetingDateMonth = $"{result.Item1.StartTime.ToString("MM")}";
                this.MeetingTime = $"{result.Item1.StartTime.ToString("HH:mm")} — {result.Item1.EndTime?.ToString("HH:mm")}";
                this.PictureUrl = result.Item1.PictureUrl;
                this.DateNow = $"{result.Item1.StartTime.ToString("yyyy")}年{MeetingDateMonth.ToString()}月{result.Item1.StartTime.ToString("dd")}日";

                this.MeetingName = result.Item1.Subject;
                this.MeetingAdress = result.Item1.Location;
                this.MeetingContent = result.Item1.MoreInfo;
            }
        }
    }
}
        


﻿// ---------------------------------------------------------------
// <author>Paul Datsyuk</author>
// <url>https://www.linkedin.com/in/pauldatsyuk/</url>
// ---------------------------------------------------------------

using MvvmCross.Core.Navigation;
using MvvmCross.Core.ViewModels;
using System.Collections.Generic;
using Xamarin.Forms;
using System;
using AXMobile.Core.Helpers;
using AXMobile.Core.Model;
using AXMobile.Core.ViewModels;
using Plugin.AzurePushNotifications;

namespace AXMobile.Core.ViewModels
{
    public class MainViewModel : MvxViewModel
    {
        private readonly IMvxNavigationService _navigationService;
        private readonly Services.IAppSettings _settings;

        public MainViewModel(IMvxNavigationService navigationService, Services.IAppSettings settings)
        {
            _navigationService = navigationService;
            _settings = settings;
            MeetingListViewModel = new MeetingListViewModel();
            ButtonText = Resources.AppResources.MainPageButton;
        }
        public MeetingListViewModel MeetingListViewModel { get; set; }
        public override async void Start()
        {
            await MeetingListViewModel.SourceToModel();
        }
        public IMvxCommand PressMeCommand =>
            new MvxCommand(() =>
            {
                ButtonText = Resources.AppResources.MainPageButtonPressed;
            });

        public IMvxAsyncCommand GoToSecondPageCommand =>
            new MvxAsyncCommand(async () =>
            {
                var param = new Dictionary<string, string> { { "ButtonText", ButtonText } };

                await _navigationService.Navigate<SecondViewModel, Dictionary<string, string>>(param);
            });

        public IMvxAsyncCommand SignOutCommand =>
           new MvxAsyncCommand(async () =>
           {
               CrossAzurePushNotifications.Current.UnregisterFromAzurePushNotification();

               await _navigationService.Navigate<LoginViewModel>();
               ClearStackHelper.ClearBackStack();
           });

        public IMvxCommand OpenGithubUrlCommand =>
            new MvxCommand(() =>
            {
                Device.OpenUri(new Uri("http://www.highviewsoft.com"));
            });

        public string ButtonText { get; set; }

        public int SuperNumber
        {
            get { return _settings.SuperNumber; }
            set { _settings.SuperNumber = value; }
        }
    }
}
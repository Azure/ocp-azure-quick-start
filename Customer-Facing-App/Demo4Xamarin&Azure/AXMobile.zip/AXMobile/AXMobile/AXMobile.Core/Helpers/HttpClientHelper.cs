﻿using AXMobile.Core.Services;
using MvvmCross.Platform;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace AXMobile.Core.Helpers
{
    public static class HttpClientHelper
    {
        private static HttpClient _client;
        public static HttpClient client => _client ?? (_client = new HttpClient());
        
        public static async Task<HttpResponseMessage> PostAsync(string url,object model)
        {
            var json = JsonConvert.SerializeObject(model);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await GetHttpClient().PostAsync(url, content);

            return response;
        }

        public static async Task<HttpResponseMessage> GetAsync(string url)
        {
            var response = await GetHttpClient().GetAsync(url);
            return response;
        }

        private static HttpClient GetHttpClient()
        {
            client.DefaultRequestHeaders.Clear();
            return client;
        }
    }
}

﻿
using Xamarin.Forms;

namespace AXMobile.Core.Helpers
{
    public class ClearStackHelper
    {
        public static void ClearBackStack()
        {
            INavigation navigation = Application.Current.MainPage.Navigation;
            if (navigation.NavigationStack.Count > 1)
            {
                var count = navigation.NavigationStack.Count;
                for (int i = 0; i < count-1; i++)
                {
                    navigation.RemovePage(navigation.NavigationStack[0]);
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace AXMobile.Core.Model
{
    public class MeetingListItem
    {
        public string MeetingDateTime { get; set; }

        public int MeetingDateTimeSize { get; set; }

        public string MeetingDateMonth { get; set; }

        public bool MeetingDateMonthVisible { get; set; }

        public string GroupHeaderBackgroundColor { get; set; }

        public string GroupHeaderTextColor { get; set; }

        public string GroupHeaderImageSource { get; set; }

        public int MeetingId { get; set; }
        public string NameText { get; set; }
        public string TimeText { get; set; }
        public string AddressText { get; set; }
    }
}

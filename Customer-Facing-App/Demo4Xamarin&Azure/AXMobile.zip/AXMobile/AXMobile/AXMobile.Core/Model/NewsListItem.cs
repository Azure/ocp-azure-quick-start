﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AXMobile.Core.Model
{
    public class NewsListItem
    {
        public string Title { get; set; }

        public DateTime CreationTime { get; set; }

        public string PictureUrl { get; set; }

        public int Id { get; set; }
    }
}

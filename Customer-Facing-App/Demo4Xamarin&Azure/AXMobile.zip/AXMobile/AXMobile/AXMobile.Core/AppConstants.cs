﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AXMobile.Core
{
    public class AppConstants
    {
        public const string Baidu_Push_Api_Key = "";
        public const string Google_Api_Sender_Id = "";
        public const string Azure_Notification_Hub_Name = "projectax";
        public const string Azure_Notification_Hub_ListenConnectionString = "Endpoint=sb://projectaxhub.servicebus.windows.net/;SharedAccessKeyName=DefaultListenSharedAccessSignature;SharedAccessKey=CexOQsnllzQWUHdxT+WQJ3TtgwXGXQwnv28nudZoD/c=";
        public const string Base_API_Url = "https://projectax.azurewebsites.net/api/";

    }
}
